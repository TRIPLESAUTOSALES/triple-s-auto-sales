export const Card = ({ children }) => <div className='rounded-xl shadow-xl'>{children}</div>;
export const CardContent = ({ children }) => <div>{children}</div>;